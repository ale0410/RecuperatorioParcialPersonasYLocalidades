var http = new XMLHttpRequest;
var trClick;
function contenedorAparecer(){
    document.getElementById("containerAgregar").hidden=false;
}
function contenedorDesaparecer(){
    document.getElementById("containerAgregar").hidden=true;
}
function loadingAparecer(){
    document.getElementById("load").hidden=false;
}
function loadingDesaparecer(){
    document.getElementById("load").hidden=true;
}

window.onload=function(){
    this.GetPersonas();
}

function armarGrilla(jsonObj){
    for(var i=0;i<jsonObj.length;i++){
        
        document.getElementById("namePeople").className = "sinError";
        document.getElementById("surNamePeople").className = "sinError";
        document.getElementById("localidad").className = "sinError";
        //document.getElementById("turno").className = "sinError";
        // tr.setAttribute("idPersona",jsonObj[i].id);
        agregarObjeto(jsonObj[i])
        /* // nodoTexto
        tCuerpo.innerHTML+=
        "<tr>"+
        "<td>"+jsonObj[i].nombre +"</td>"+
        "<td>"+jsonObj[i].apellido +"</td>"+
        "<td>"+jsonObj[i].fecha +"</td>"+
        "<td>"+jsonObj[i].telefono +"</td>"+
        "<td><a href=''>borrar</a></td>"+
        "</tr>";*/
        
    }
}
function agregarObjeto(objeto){
    var tCuerpo = document.getElementById("tablaPersonas");
    var tr =document.createElement("tr");
    tr.setAttribute("idPersona",objeto.id);
    //Agrega una row
    var td =document.createElement("td");
    var nodoTexto1 = document.createTextNode(objeto.nombre);
    td.appendChild(nodoTexto1);
    tr.appendChild(td); //agrego la row a la tabla 

    var td2 =document.createElement("td");
    var nodoTexto2 = document.createTextNode(objeto.apellido);
    td2.appendChild(nodoTexto2);
    tr.appendChild(td2); //agrego la row a la tabla 

    var td3 =document.createElement("td");
    var nodoTexto3 = document.createTextNode(objeto.localidad.nombre);
    td3.appendChild(nodoTexto3);
    tr.appendChild(td3); //agrego la row a la tabla 

    var td4 =document.createElement("td");
    var nodoTexto4 = document.createTextNode(objeto.sexo);
    td4.appendChild(nodoTexto4);
    tr.appendChild(td4); //agrego la row a la tabla 

    
    tr.addEventListener("dblclick",clickGrilla);
    tCuerpo.appendChild(tr);
}
function agregarPersona(objeto){
        var tCuerpo = document.getElementById("tablaPersonas");
        var tr =document.createElement("tr");
        tr.setAttribute("idPersona",objeto.id);
        //Agrega una row
        var td =document.createElement("td");
        var nodoTexto1 = document.createTextNode(objeto.nombre);
        td.appendChild(nodoTexto1);
        tr.appendChild(td); //agrego la row a la tabla 

        var td2 =document.createElement("td");
        var nodoTexto2 = document.createTextNode(objeto.apellido);
        td2.appendChild(nodoTexto2);
        tr.appendChild(td2); //agrego la row a la tabla 

        var td3 =document.createElement("td");
        var nodoTexto3 = document.createTextNode(objeto.localidad.nombre);
        td3.appendChild(nodoTexto3);
        tr.appendChild(td3); //agrego la row a la tabla 

        
        var td4 =document.createElement("td");
        var nodoTexto4 = document.createTextNode(objeto.sexo);
        td4.appendChild(nodoTexto4);
        tr.appendChild(td4); //agrego la row a la tabla 

        
        tr.addEventListener("dblclick",clickGrilla);
        tCuerpo.appendChild(tr);
}

function GetPersonas(){
    http.onreadystatechange = function(){
        if(http.readyState == 4 && http.status == 200){
            //console.log(http.responseText);
            obj =JSON.parse(http.responseText) 
            armarGrilla(obj);
        }
    }
    http.open("GET","http://localhost:3000/personas",true);
    http.send();
}


function clickGrilla(e){
    trClick = e.target.parentNode;
    var personaT = ["Nombre", "Apellido", "Localidad", "Sexo"];
    //console.log(e);
    //console.log(e.target.parentNode.childNodes[0].innerHTML);//esto me da una lista de tds
    //document.getElementById("nombre") = trClick.childNodes[0].innerHTML;
    contenedorAparecer(); //Llama al contenedorAparecer
    document.getElementById("namePeople").value = trClick.childNodes[0].textContent;
    document.getElementById("surNamePeople").value = trClick.childNodes[1].textContent;
    document.getElementById("localidad").value = trClick.childNodes[2].textContent;
    var form = document.getElementById("containerAgregar");

    /*personaT.forEach(function (elemento, indice) 
    {
        var select = document.getElementById("localidad").value;
        select = document.createElement('select');

        switch (elemento) {

            case 'Localidad':

                var select = createSelect();
                select.setAttribute('id', 'selectFormulario');

                form.appendChild(select);

                //elemento.addEventListener('change', (event) => {


                    //setSpinner('show');
        
                    //obtenerDatosFila(elemento.parentNode.parentNode);
        
                //});

                break;
        }

    });*/

        if(trClick.childNodes[3].textContent == "Female")
        {
            document.getElementById("rdFemale").checked = true;
        }
        else{
            document.getElementById("rdMale").checked = true;
        }
        
        var btnModificar = document.getElementById("btnUpdate");

    //select.setAttribute('id', 'selectFormulario');

    //const selectElements = document.querySelectorAll('.selectLocalidad');

    /*selectElements.forEach(element => {


        

    });*/


    // trClick.removeChild(trClick.childNodes[0]);
    
}


function obtenerDatosFila(tr) {

    nuevaLocalidad = {
        "id": tr.children[0].textContent,
        "nombre": tr.children[3].children[0].value

    }

    modificarLocalidad(nuevaLocalidad);



}


function modificarLocalidad(nuevaLocalidad) {
    var xhr = new XMLHttpRequest();
    var url = "http://localhost:3000/localidades";
    xhr.open('POST', url, true);
    xhr.setRequestHeader("Content-Type", "application/json");
    xhr.send(JSON.stringify(nuevaLocalidad));
    xhr.onreadystatechange = respuestaLocalidad;


}


function respuestaLocalidad() {

    if (xhr.readyState == 4) {

        if (xhr.status == 200) {
            var respuesta = JSON.parse(xhr.responseText);
            if (respuesta.type == "ok") {

                if (nuevoAño  != null) {
                    cambiarFila(nuevaLocalidad);
                    //setSpinner();
                }
            }
        }
    }

}


function cambiarFila(nuevaLocalidad) {

    document.querySelectorAll('tr').forEach(function (value, index) {



        if (value.children[0].textContent == nuevaLocalidad.id) {


            value.children[3].children[0].value = nuevaLocalidad.nombre;


        }

    });


}


function Modificar(){
     if(ValidarDatos()==true){
            ejecutarModificar();
        }

}

function actualizarElemento(){
    trClick.childNodes[0].textContent = document.getElementById("namePeople").value;
    trClick.childNodes[1].textContent = document.getElementById("surNamePeople").value;
    trClick.childNodes[2].textContent = document.getElementById("localidad").value;
    
    if(document.getElementById("rdFemale").checked == true)
    {
        trClick.childNodes[3].textContent = "Female"
       }
       else{
           trClick.childNodes[3].textContent = "Male"
       }
}

function ValidarDatos(){
    var nombre = document.getElementById("namePeople");
    var apellido = document.getElementById("surNamePeople");

    if(nombre.value == "" || nombre.value.length <= 3){
        nombre.className = "error";
        return false;
    }
    if(apellido.value == "" || apellido.value.length <= 3){
        apellido.className = "error";
        return false;
    }
    
    return true;

}


function ejecutarModificar(){
    document.getElementById("containerGlobal").hidden=true;
    loadingAparecer();
    var respuesta;
    var httpPost = new XMLHttpRequest();
    httpPost.onreadystatechange=function(){        
        if(httpPost.readyState==4 ){
            loadingDesaparecer();
            document.getElementById("containerGlobal").hidden=false;
            contenedorDesaparecer();          
            respuesta = JSON.parse(httpPost.responseText);
            if(respuesta.type == "ok")
                {
                  actualizarElemento();  
                }
                //console.log(httpPost.responseText);
                //location.reload();
            
        }
    }

    //var localidad = document.getElementById("localidad").value;
    //var mod = modificarLocalidad(localidad);
    
    httpPost.open("POST","http://localhost:3000/editar",true);
    httpPost.setRequestHeader("Content-Type","application/json");
    var json = {
        "id": trClick.getAttribute("idPersona"),
        "nombre": document.getElementById("namePeople").value,
        "apellido": document.getElementById("surNamePeople").value,
        "localidad": document.getElementById("localidad").value,
        "sexo": document.getElementById("rdMale")?"Male":"Female"
    }
    //var json ={"id":id,"nombre":nombre,"apellido":apellido,"fecha":fecha,"sexo":sexo};
    //var json ={"nombre":nombre,"apellido":apellido,"fecha":fecha,"telefono":telefono};
    httpPost.send(JSON.stringify(json));
    //CONTROL-C podes matar la api via console
    /// PONER UN GIFT CARGANDO Y CUANDO YA VUELVA EL SERVIDOR SACAR EL GIFT Y RECARGAR LA GRILLA CON LA RESPUESTA DEL SERVIDOR 
}


/*function createSelect() {


    var select = document.createElement('select');
    select.setAttribute('class', "selectTable");


    for (var i = 2000; i <= 2020; i++) {

        option = document.createElement("option");
        option.setAttribute("value", i);

        var texto = document.createTextNode(i);
        option.appendChild(texto);

        select.appendChild(option);



    }


    return select;
}*/



